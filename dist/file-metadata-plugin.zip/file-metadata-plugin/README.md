# file-metadata-plugin
A Pentaho Data Integration plugin to enable file metadata scanning
